//ELINE-ELORM AWO NUVIADENU//
//101162869//
package Store;

import java.util.ArrayList;

/**
 * An inventory class
 * @author Eline Nuviadenu
 * @version 1.0
 */
public class Inventory {

    private ArrayList<String> typeList;
    private ArrayList<Integer> quantityList;
    private ArrayList<Product> productList;

    public Inventory(){

        /**
         * Constructor for the Store.Inventory class
         */
        this.typeList = new ArrayList<>();
        this.quantityList= new ArrayList<>();
        this.productList= new ArrayList<>();
    }

    /**
     * Accessor for the amount of stock in the inventory
     * @param productID validates if the item is actually in stock
     * @return the amount of product in stock
     */
    public int getAmountOfStock(int productID){
        for (Product p: this.productList){
            if (p.getProductID() == productID){
                int index = this.productList.indexOf(p);
                return this.quantityList.get(index);
            }
        }
        return -1;
    }

    /**
     * Method to add more to a product's quantity or to create a new product if it does not exist
     * @param product specifies the name of the product
     * @param productType specifies the type of the product
     * @param amount quantity of product that will be added
     */
    public void addAmountOfStock(Product product, String productType, int amount){
        for (Product p: this.productList){
            if (p.getProductID() == product.getProductID()){
                int index = this.productList.indexOf(product);
                int newAmount = this.quantityList.get(index) + amount;
                this.quantityList.set(index, newAmount);
            }
        }
        if (!this.productList.contains(product)){
            this.productList.add(product);
            this.quantityList.add(amount);
            this.typeList.add(productType);
        }
    }

    /**
     * Method to remove a quantity of an item from stock
     * @param productID gets the product whose quantity you want reduced
     * @param amount specifies the amount you want the quantity to be reduced by
     * @return whether or not the removal was successful
     */
    public boolean removeAmountOfStock(int productID, int amount){
        for (Product p: this.productList){
            if (p.getProductID() == (productID)) {
                int index = this.productList.indexOf(p);
                int quantity = this.quantityList.get(index);
                if (quantity > amount) {
                    this.quantityList.set(index, quantity - amount);
                    return true;
                } else if (quantity <= amount){
                    this.quantityList.set(index, 0);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Gets the reference of the product
     * @param productID specifies the product we want to return
     * @return the reference of the product
     */
    public Product getInfo(int productID){
        for (Product p: this.productList) {
            if (p.getProductID() == productID) {
                return p;
            }
        }
        return null;
    }

    /**
     * A method that gets the type of product
     * @param productID specifies the product
     * @return the type of product
     */
    public String getProductType (int productID){
        int index = 0;
        for (Product p: this.productList) {
            if (p.getProductID() == (productID)) {
                index = this.productList.indexOf(p);
            }
        }
        return this.typeList.get(index);
    }

    /**
     * A method to get the list of products
     * @return the product list
     */
    public ArrayList<Product> getProductList() {
        return this.productList;
    }
}
