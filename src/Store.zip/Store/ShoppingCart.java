//ELINE-ELORM AWO NUVIADENU//
//101162869//
package Store;
import java.util.HashMap;

/**
 * A Store.ShoppingCart class
 * @author Eline Nuviadenu
 * @version 0.0
 */
public class ShoppingCart {

    private HashMap<Integer, Integer> cartContents = new HashMap<Integer, Integer>();

    /**
     * A method to add a product to a cart
     *
     * @param productID refers to the product a user wants to add to cart
     * @param quantity  refers to the amount of product a user wants to add to their cart
     */
    public void addToCart(int productID, int quantity) {
        if (this.cartContents.containsKey(productID)) {
            int oldValue = this.cartContents.get(productID);
            this.cartContents.replace(productID, oldValue, oldValue + quantity);
        } else {
            this.cartContents.put(productID, quantity);
        }
    }

    /**
     * A method to remove a product from a cart
     *
     * @param productID refers to the product a user wants to remove from their cart
     * @param quantity  refers to the amount of product to be removed
     * @return true if successful, false if failed
     */
    public boolean removeFromCart(int productID, int quantity) {
        int oldValue = this.cartContents.get(productID);
        if (this.cartContents.containsKey(productID) && oldValue >= quantity) {
            this.cartContents.replace(productID, oldValue, oldValue - quantity);
            return true;
        } else if (this.cartContents.containsKey(productID) && oldValue == quantity) {
            this.cartContents.remove(productID);
            return true;
        }
        return false;
    }

    /**
     * a method to get the contents of a cart
     *
     * @return the contents of a cart
     */
    public HashMap<Integer, Integer> getCartContents() {
        return this.cartContents;
    }


}
