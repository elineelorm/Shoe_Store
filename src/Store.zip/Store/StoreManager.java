//ELINE-ELORM AWO NUVIADENU//
//101162869//
package Store;

import Store.Inventory;
import Store.Product;
import Store.ShoppingCart;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * A Storemanager class
 * @author Eline Nuviadenu
 * @version 1.1
 */
public class StoreManager {

    private Inventory inventory;
    private ArrayList<ShoppingCart> shoppingCarts;
    private int newID = -1;

    /**
     * Constructor for the class
     */
    public StoreManager(){
        this.inventory = new Inventory();
        this.shoppingCarts = new ArrayList<ShoppingCart>();
    }

    /**
     * Method to check the amount of product available in the inventory
     * @param product specifies the product whose quantity we want to get
     * @return the amount of product available
     */
    public int checkStock(Product product){
        return this.inventory.getAmountOfStock(product.getProductID());
    }

    /**
     * A method to calculate the amount a user has to pay
     * @param cartID refers to a users cart
     */
    public String checkout( int cartID){
        HashMap<Integer, Integer> cartList = this.getShoppingCart().get(cartID).getCartContents();
        double amountToPay = 0.0;
        for (Integer id: cartList.keySet()){
            Product product = this.inventory.getInfo(id);
            double price = product.getProductPrice();
            amountToPay += price * cartList.get(id);
        }
        this.getShoppingCart().get(cartID).getCartContents().clear();
        return "Your total amount to pay is: $" + String.format("%.2f", amountToPay) + "\n" +
                "Come back soon!";
    }

    /**
     * A method to give each user a specific cart id
     * @return a new id for each user
     */
    public int assignNewCartID(){
        this.newID += 1;
        ShoppingCart cart = new ShoppingCart();
        this.shoppingCarts.add(cart);
        return this.newID;
    }

    /**
     * A method to add a product to a cart and remove from inventory
     * @param productID refers to the specific product we want to add
     * @param quantity refers to the amount of a product a user wants to add to cart
     * @param cartID refers to the users cart id
     * @return true if addition was successful, false if unsuccessful
     */
    public boolean addProduct(int productID, int quantity, int cartID) {
        if (this.inventory.getAmountOfStock(productID) >= quantity && quantity > 0) {
            this.inventory.removeAmountOfStock(productID, quantity);
            this.shoppingCarts.get(cartID).addToCart(productID, quantity);
            return true;
        }
        System.out.println("Amount of stock is not available, please go back and re-select :(");
        return false;
    }

    /**
     * A method to remove an item from a users cart and add to the inventory
     * @param productID refers to the specific product we want to remove
     * @param quantity refers to the amount of product a user wants to remove from cart
     * @param cartID refers to the users cart id
     */
    public void removeProduct(int productID, int quantity, int cartID){
        if (getShoppingCart().get(cartID).getCartContents().get(productID) >= quantity && quantity > 0) {
            Product p = this.inventory.getInfo(productID);
            String t = this.inventory.getProductType(productID);
            this.inventory.addAmountOfStock(p, t, quantity);
            this.shoppingCarts.get(cartID).removeFromCart(productID, quantity);
        }else {
            System.out.println("Amount is out of bounds! Kindly make another selection :(");
        }
    }

    /**
     * A method that allows a user to quit before checking out
     * @param cartID refers to the users cart id
     */
    public void quit(int cartID){
        for (Integer id: this.getShoppingCart().get(cartID).getCartContents().keySet()){
            Product p = this.inventory.getInfo(id);
            String t = this.inventory.getProductType(id);
            int q = this.shoppingCarts.get(cartID).getCartContents().get(id);
            this.inventory.addAmountOfStock(p, t, q);
        }
        this.getShoppingCart().get(cartID).getCartContents().clear();
    }

    /**
     * A method to get the list of shopping carts
     * @return a list of shopping carts
     */
    public ArrayList<ShoppingCart> getShoppingCart() {
        return this.shoppingCarts;
    }

    /**
     * A method to get the Store.Inventory
     * @return the contents of the inventory
     */
    public Inventory getInventory() {
        return this.inventory;
    }

    /**
     * A method to return the cart id
     * @return the cart id
     */
    public int getCartID(){
        return this.newID;
    }
}
