//ELINE-ELORM AWO NUVIADENU//
//101162869//
package Store;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * A Storemanager class
 * @author Eline Nuviadenu
 * @version 1.0
 */
public class StoreView {

    /**
     * A Storeview class
     */
    private StoreManager storeManager;
    private int cartID;

    /**
     * Constructor for the storeview class
     * @param storeManager refers to the storemanager class which controls the storeview
     * @param cartID refers to the users unique cart id
     */
    public StoreView(StoreManager storeManager, int cartID){
        this.storeManager = storeManager;
        this.cartID = cartID;
    }

    /**
     * A method that displays the way a user sees and interacts with the store
     * @return true if successful, false if failed
     */
    public boolean displayGUI() {
        System.out.println("Type one of these available commands: browse, add, remove, checkout, quit");
        Scanner s = new Scanner(System.in);
        String chooseCommand = s.next();
        if (chooseCommand.equalsIgnoreCase("browse")) {
            System.out.println("********************ELINE'S HUB********************");
            System.out.println("********************** HOME! **********************");
            System.out.println("Stock     |     Store.Product Name     |     Unit Price     ");
            for (Product p : this.storeManager.getInventory().getProductList()) {
                System.out.println(this.storeManager.getInventory().getAmountOfStock(p.getProductID()) +
                        " | " + p.getProductName() + " | " + p.getProductPrice());
            }
        }
        if (chooseCommand.equalsIgnoreCase("add")) {
            int option = -1;
            System.out.println("********************ELINE'S HUB********************");
            System.out.println("******************* ADD TO CART *******************");
            System.out.println("Stock  |  Store.Product Name   |   Unit Price  | Option  ");
            for (Product p : this.storeManager.getInventory().getProductList()) {
                option++;
                System.out.println(this.storeManager.checkStock(p) + " | " + p.getProductName() + " | " +
                        p.getProductPrice() + " | " + option);
            }
            System.out.print("Enter an option: ");
            int optionChosen;
            while (true) {
                try {
                    optionChosen = s.nextInt();
                    break;
                } catch (InputMismatchException ime) {
                    System.out.println("MAIN > ERROR > BAD CHOICE\nTHAT OPTION DOES NOT EXIST\nTYPE A NEW OPTION: OPTION MUST BE A NUMBER");
                    s.reset();
                    s.next();
                }
            }
            if (optionChosen <= option && optionChosen >= 0) {
                System.out.print("How many of this product would you like to purchase?");
                int add;
                while (true) {
                    try {
                        add = s.nextInt();
                        break;
                    } catch (InputMismatchException ime) {
                        System.out.println("MAIN > ERROR > BAD CHOICE\nTHAT OPTION DOES NOT EXIST\nTYPE A NEW OPTION: OPTION MUST BE A NUMBER");
                        s.reset();
                        s.next();
                    }
                }
                this.storeManager.addProduct(this.storeManager.getInventory().getProductList().get(optionChosen).getProductID(),
                        add, this.cartID);
            } else {
                System.out.println("Error :(, Check number entered!");
            }
        }
        if (chooseCommand.equalsIgnoreCase("remove")) {
            int option = -1;
            System.out.println("********************ELINE'S HUB********************");
            System.out.println("***************** REMOVE FROM CART ****************");
            System.out.println("Quantity In Cart    |  Store.Product Name   |   Unit Price  |   Option  ");
            for (Product p : this.storeManager.getInventory().getProductList()) {
                option++;
                System.out.println(this.storeManager.getShoppingCart().get(this.cartID).getCartContents().get(p.getProductID()) + " | " + p.getProductName() + " | " +
                        p.getProductPrice() + " | " + option);
            }
            System.out.println("Enter an option: ");
            int optionChosen;
            while (true) {
                try {
                    optionChosen = s.nextInt();
                    break;
                } catch (InputMismatchException ime) {
                    System.out.println("MAIN > ERROR > BAD CHOICE\nTHAT OPTION DOES NOT EXIST\nTYPE A NEW OPTION: OPTION MUST BE A NUMBER");
                    s.reset();
                    s.next();
                }
            }
            if (optionChosen <= option && optionChosen >= 0) {
                System.out.println("How many of this product would you like to remove? ");
                int remove;
                while (true) {
                    try {
                        remove = s.nextInt();
                        break;
                    } catch (InputMismatchException ime) {
                        System.out.println("MAIN > ERROR > BAD CHOICE\nTHAT OPTION DOES NOT EXIST\nTYPE A NEW OPTION: OPTION MUST BE A NUMBER");
                        s.reset();
                        s.next();
                    }
                }
                this.storeManager.removeProduct(this.storeManager.getInventory().getProductList().get(optionChosen).getProductID(),
                        remove, this.cartID);
            } else {
                System.out.println("Error :(, Check number entered!");
            }
        }
        if (chooseCommand.equalsIgnoreCase("checkout")) {
            System.out.println("Below are the product id's and the quantities you ordered.");
            for (Integer item : this.storeManager.getShoppingCart().get(this.cartID).getCartContents().keySet()) {
                Product p = this.storeManager.getInventory().getInfo(item);
                System.out.println(p.getProductName() + ", " + this.storeManager.getShoppingCart().get(this.cartID).getCartContents().get(item));
            }
            System.out.println(this.storeManager.checkout(this.cartID));
            return true;
        }
        if (chooseCommand.equalsIgnoreCase("quit")) {
            this.storeManager.quit(this.cartID);
            return true;
        }
        return false;
    }


    /**
     * This is where we interact with the classes created
     * @param args refers to the inputs that will aid in the communication with the class
     */
    public static void main(String[] args) {

        Product p1 = new Product("Heels", 5678,230.89);
        Product p2 = new Product("Lip balm", 7368, 5.99);
        Product p3 = new Product("Pencils", 2637, 4.99);

        StoreManager sm = new StoreManager();

        sm.getInventory().addAmountOfStock(p1, "shoes", 23);
        sm.getInventory().addAmountOfStock(p2, "beauty", 30);
        sm.getInventory().addAmountOfStock(p3, "stationery", 50);

        StoreView sv1 = new StoreView(sm, sm.assignNewCartID());
        StoreView sv2 = new StoreView(sm, sm.assignNewCartID());
        StoreView sv3 = new StoreView(sm, sm.assignNewCartID());
        StoreView[] users = {sv1, sv2, sv3};
        int activeSV = users.length;
        Scanner sc = new Scanner(System.in);
        int choice;

        while (activeSV > 0) {
            while (true) {
                System.out.print("CHOOSE YOUR STOREVIEW >>> ");
                try {
                    choice = sc.nextInt();
                    break;
                } catch (InputMismatchException ime) {
                    System.out.println("MAIN > ERROR > BAD CHOICE\nTHAT STOREVIEW DOES NOT EXIST");
                    sc.reset();
                    sc.next();
                }
            }
            if (choice < users.length && choice >= 0) {
                if (users[choice] != null) {
                    System.out.println("CART >>> " + users[choice].cartID);
                    System.out.println("Welcome! :)");
                    String chooseAnother = "";
                    while (!chooseAnother.equals("y") && !chooseAnother.equals("Y")) {
// this implementation of displayGUI waits for input and displays the page
// corresponding to the user's input. it does this once, and then returns
// true if the user entered 'checkout' or 'quit'.
                        if (users[choice].displayGUI()) {
                            users[choice] = null;
                            activeSV--;
                            break;
                        }
                        System.out.println("\nType y for yes and anything else for no, but preferably n");
                        System.out.print("GO TO ANOTHER STOREVIEW? (y) >>> ");
                        chooseAnother = sc.next();
                        System.out.println("CART >>> " + users[choice].cartID);
                    }
                } else {
                    System.out.println("MAIN > ERROR > BAD CHOICE\nTHAT STOREVIEW WAS DEACTIVATED");
                }
            } else {
                System.out.println(
                        String.format("MAIN > ERROR > BAD CHOICE\nPLEASE CHOOSE IN RANGE [%d, %d]",
                                0, users.length - 1)
                );
            }
        }
        System.out.println("ALL STOREVIEWS DEACTIVATED");
    }
}
